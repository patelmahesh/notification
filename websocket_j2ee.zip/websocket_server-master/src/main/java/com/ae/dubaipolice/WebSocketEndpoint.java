/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 */
package com.ae.dubaipolice;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.websocket.CloseReason;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

/**
 *
 * @author INTERACTIVE
 */
@ServerEndpoint("/socket/{userId}")
public class WebSocketEndpoint {

    //private static Set<Session> socketSessions = Collections.synchronizedSet(new HashSet<Session>());
    private static final Map<String, Session> socketSessions = new HashMap<>();

    private String userId;

    @OnOpen
    public void open(@PathParam("userId") String userId, Session session) {
        this.userId = userId;
        socketSessions.put(userId, session);
        session.setMaxIdleTimeout(0);
        System.out.println("Socket Opened " + session.getId());
    }

    @OnClose
    public void close(Session session, CloseReason reason) throws Exception {
        System.out.println("Socket Closed " + session.getId());
        socketSessions.values().remove(session);
    }

    @OnError
    public void onError(Throwable error, Session session) {
        try {
            session.getBasicRemote().sendText("Error " + error.getMessage());
            System.out.println("Error  " + error.getMessage());
        } catch (Exception e) {
            System.out.println("asdf" + e);
        }

    }

    @OnMessage
    public void broadcast(String message) throws IOException {
        for (Map.Entry<String, Session> entry : socketSessions.entrySet()) {
            String userId = entry.getKey();
            Session value = entry.getValue();
            value.getBasicRemote().sendText(message);

        }
    }

}
